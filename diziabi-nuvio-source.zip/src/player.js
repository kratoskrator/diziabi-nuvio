'use strict';
var u = require('./utils');
var http = require('./http');
var media = require('./media');
var MAX_FRAMES = 4;
var MAX_VARIANTS = 4;

function playerOrigin(url) {
  var root = u.origin(url);
  return /^https:\/\/(?:[a-z0-9-]+\.)*pilavyerplay\.top$/i.test(root) ? root : '';
}
function safeURL(url) {
  return /^https:\/\/[a-z0-9.-]+(?:\/[\x21-\x7e]*)?$/i.test(String(url || '')) && !/[<>"\\]/.test(url);
}
function samePlayerURL(value, base, kind) {
  var url = u.absolute(value, base), root = playerOrigin(base);
  if (!root || !safeURL(url) || !u.sameSite(url, root)) return '';
  var path = url.slice(root.length).split(/[?#]/)[0];
  if (kind === 'stream' && path !== '/api/stream.php') return '';
  if (kind === 'subtitle' && path !== '/api/sub.php' && !/\.(?:vtt|srt)$/i.test(path)) return '';
  return url;
}
function frames(html, pageURL) {
  html = String(html || '').replace(/<!--[\s\S]*?-->/g, '');
  var bases = [], slugs = [], found = [], match;
  var scripts = /<script\b[^>]*>/gi;
  while ((match = scripts.exec(html))) {
    var src = u.absolute(u.attr(match[0], 'src'), pageURL);
    if (!/\/(?:assets\/js\/core|e\/c)\.js(?:[?#]|$)/i.test(src)) continue;
    var base = playerOrigin(src);
    if (base && bases.indexOf(base) < 0) bases.push(base);
  }
  var containers = /<div\b[^>]*>/gi;
  while ((match = containers.exec(html)) && slugs.length < MAX_FRAMES) {
    var slug = u.attr(match[0], 'data-pv');
    if (/^[A-Za-z0-9_-]{8,128}$/.test(slug) && slugs.indexOf(slug) < 0) slugs.push(slug);
  }
  // The public loader constructs this exact iframe URL from data-pv. Its code
  // is never downloaded or executed during a provider lookup.
  bases.slice(0, 1).forEach(function (base) {
    slugs.forEach(function (slug) { found.push(base + '/assets/js/s.php?s=' + encodeURIComponent(slug)); });
  });
  var iframes = /<iframe\b[^>]*>/gi;
  while ((match = iframes.exec(html)) && found.length < MAX_FRAMES) {
    var frame = u.absolute(u.attr(match[0], 'src'), pageURL);
    if (playerOrigin(frame) && safeURL(frame) && /\/assets\/js\/s\.php\?s=[A-Za-z0-9_-]{8,128}(?:&|$)/.test(frame) && found.indexOf(frame) < 0) found.push(frame);
  }
  return found.slice(0, MAX_FRAMES);
}
function configuration(html) {
  html = String(html || '');
  if (html.length > 1024 * 1024) return null;
  var scripts = /<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi, match;
  while ((match = scripts.exec(html))) {
    if (u.attr(match[1], 'src')) continue;
    var assignment = /^\s*window\.__PLAYER__\s*=\s*(\{[\s\S]*\})\s*;?\s*$/.exec(match[2]);
    if (!assignment || assignment[1].length > 256 * 1024) continue;
    try {
      var value = JSON.parse(assignment[1]);
      if (value && typeof value === 'object' && !Array.isArray(value) && typeof value.stream === 'string') return value;
    } catch (ignored) {}
  }
  return null;
}
function variants(body, base) {
  var lines = String(body || '').split(/\r?\n/), found = [];
  for (var i = 0; i < lines.length; i++) {
    if (!/^\s*#EXT-X-STREAM-INF:/i.test(lines[i])) continue;
    var resolution = /\bRESOLUTION=(\d+)x(\d+)/i.exec(lines[i]);
    var next = i + 1;
    while (next < lines.length && (!lines[next].trim() || /^\s*#/.test(lines[next]))) next++;
    if (next === lines.length) return [];
    var url = samePlayerURL(lines[next].trim(), base, 'stream');
    if (!url) return [];
    found.push({ url: url, height: resolution ? Number(resolution[2]) : 0 });
    if (found.length > MAX_VARIANTS) return [];
  }
  return found;
}
function duration(body) {
  if (!/#EXT-X-ENDLIST(?:\s|$)/i.test(body)) return 0;
  var re = /#EXTINF:([\d.]+)/gi, match, total = 0;
  while ((match = re.exec(body))) total += Number(match[1]) || 0;
  return total;
}
function compatibleEpisode(config, meta) {
  if (!meta || !/^(?:tv|series|show)$/i.test(meta.kind || '')) return true;
  var episode = /(?:^|[.\s_-])S(\d{1,3})E(\d{1,4})(?=[.\s_-]|$)/i.exec(config.title || '');
  return !episode || Number(episode[1]) === Number(meta.season) && Number(episode[2]) === Number(meta.episode);
}
function playbackHeaders(frame) {
  var root = playerOrigin(frame);
  return { Referer: root + '/', Origin: root, 'User-Agent': http.USER_AGENT, 'Accept-Language': 'tr-TR,tr;q=0.9,en;q=0.8' };
}
function subtitles(config, frame, headers) {
  var found = [], seen = {};
  (Array.isArray(config.subs) ? config.subs : []).slice(0, 12).forEach(function (sub) {
    if (!sub || typeof sub !== 'object') return;
    var url = samePlayerURL(sub.src, frame, 'subtitle');
    if (!url || seen[url]) return;
    seen[url] = true;
    var language = /^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})?$/.test(String(sub.lang || '')) ? String(sub.lang) : 'und';
    found.push({ id: 'diziabi-' + found.length, url: url, language: language, name: u.text(sub.label || language).slice(0, 100), headers: headers });
  });
  return found;
}
function audioLabel(config) {
  var labels = [];
  (Array.isArray(config.audios) ? config.audios : []).slice(0, 8).forEach(function (audio) {
    var label = u.text(audio && (audio.label || audio.lang) || '').slice(0, 80);
    if (label && labels.indexOf(label) < 0) labels.push(label);
  });
  return labels.join(' / ');
}
function verifyPlaylist(body, expectedDuration) {
  if (!media.hls(body)) return false;
  var seconds = duration(body);
  if (!seconds || seconds < 10) return false;
  // The page supplies the full asset's duration. Reject obvious previews even
  // when their playlist header looks valid; never use its filename for quality.
  return !expectedDuration || seconds >= expectedDuration * 0.8;
}
function resolveFrame(frame, page, cfg, meta) {
  return http.request(frame, { session: cfg.session, referer: u.origin(page.url) + '/', responseInfo: true }).then(function (response) {
    if (!playerOrigin(response.finalUrl) || !u.sameSite(response.finalUrl, frame)) return [];
    var config = configuration(response.body);
    if (!config || !compatibleEpisode(config, meta)) return [];
    var stream = samePlayerURL(config.stream, frame, 'stream');
    if (!stream) return [];
    var headers = playbackHeaders(frame);
    return http.request(stream, { session: cfg.session, headers: headers, responseInfo: true }).then(function (master) {
      if (!u.sameSite(master.finalUrl, frame)) return [];
      var info = media.hls(master.body);
      if (!info) return [];
      var children = variants(master.body, stream);
      var hasVariants = /#EXT-X-STREAM-INF:/i.test(master.body);
      if (hasVariants && !children.length) return [];
      var expected = Number(config.dur);
      if (!(expected >= 10 && expected <= 86400)) expected = 0;
      var validation = children.length ? Promise.all(children.map(function (child) {
        return http.request(child.url, { session: cfg.session, headers: headers, responseInfo: true }).then(function (response) {
          return u.sameSite(response.finalUrl, frame) && verifyPlaylist(response.body, expected);
        });
      })).then(function (results) { return results.every(function (valid) { return valid; }); }) : Promise.resolve(verifyPlaylist(master.body, expected));
      return validation.then(function (valid) {
        if (!valid) return [];
        var title = (meta && meta.title || 'DiziAbi') + (meta && /^(?:tv|series|show)$/i.test(meta.kind || '') ? ' S' + meta.season + 'E' + meta.episode : '');
        var audio = audioLabel(config);
        return [{ name: 'DiziAbi', provider: 'DiziAbi', title: title + ' | Pilavyer' + (audio ? ' | ' + audio : '') + (info.codecSummary ? ' | ' + info.codecSummary : ''), url: stream, type: 'hls', quality: info.quality || 'Auto', headers: headers, subtitles: subtitles(config, frame, headers) }];
      });
    });
  });
}
function resolve(page, cfg, meta) {
  cfg = cfg || {};
  if (!cfg.session) cfg.session = http.session();
  if (!page || typeof page.html !== 'string' || !/^https:\/\//i.test(page.url || '')) return Promise.resolve([]);
  var choices = frames(page.html, page.url);
  if (!choices.length) return Promise.resolve([]);
  // Independent players need not all respond before a confirmed source can be
  // played. Keep full manifest validation inside each player before selecting it.
  return new Promise(function (resolve) {
    var remaining = choices.length, finished = false;
    function complete(streams) {
      if (finished) return;
      remaining--;
      if (streams.length) {
        finished = true;
        http.cancel(cfg.session);
        resolve(streams);
      } else if (!remaining) {
        finished = true;
        resolve([]);
      }
    }
    choices.forEach(function (frame) {
      resolveFrame(frame, page, cfg, meta).then(complete, function () { complete([]); });
    });
  });
}
module.exports = { resolve: resolve, frames: frames, configuration: configuration, variants: variants, duration: duration };

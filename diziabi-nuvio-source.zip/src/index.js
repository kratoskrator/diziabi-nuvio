'use strict';
var u = require('./utils');
var http = require('./http');
var catalog = require('./catalog');
var player = require('./player');
var DEFAULT_SITE = 'https://www.diziabi.net';

function settings() {
  var root = typeof globalThis !== 'undefined' ? globalThis : {};
  var saved = root.SCRAPER_SETTINGS || {};
  return {
    site: u.siteUrl(saved.siteUrl || DEFAULT_SITE) || DEFAULT_SITE,
    key: String(saved.tmdbApiKey || root.TMDB_API_KEY || '').trim(),
    session: http.session()
  };
}

function metadata(id, kind, cfg) {
  if (!cfg.key) return Promise.reject(new Error('TMDB key unavailable. Enter your own key in DiziAbi TV settings.'));
  var token = cfg.key.length > 40;
  var url = 'https://api.themoviedb.org/3/' + kind + '/' + encodeURIComponent(id) + '?language=tr-TR';
  if (!token) url += '&api_key=' + encodeURIComponent(cfg.key);
  return http.request(url, { json: true, bearer: token ? cfg.key : '', session: cfg.session }).then(function (data) {
    var title = String(kind === 'movie' ? data.title || '' : data.name || '');
    var original = String(kind === 'movie' ? data.original_title || '' : data.original_name || '');
    var year = Number(String(kind === 'movie' ? data.release_date || '' : data.first_air_date || '').slice(0, 4));
    if ((!title && !original) || !year || (data.id && String(data.id) !== String(id))) throw new Error('Title metadata is incomplete.');
    return { title: title || original, originalTitle: original, year: year, kind: kind };
  });
}

function warn(error) {
  console.warn('[DiziAbi TV] ' + (error && error.providerSafe ? error.message : 'Source unavailable or title could not be confirmed.'));
}

function findTitle(meta, cfg) {
  var queries = [meta.title, meta.originalTitle].filter(function (value, index, all) { return value && all.indexOf(value) === index; }).slice(0, 2);
  return Promise.all(queries.map(function (query) {
    return http.request(cfg.site + '/ara/oneri?q=' + encodeURIComponent(query), { json: true, referer: cfg.site + '/', session: cfg.session }).then(function (data) {
      return catalog.parseSuggestions(data, cfg.site, meta.kind, meta);
    }).catch(function (error) { warn(error); return []; });
  })).then(function (groups) {
    var candidates = [], seen = {};
    groups.forEach(function (group) { group.forEach(function (candidate) {
      if (!seen[candidate.url]) { seen[candidate.url] = true; candidates.push(candidate); }
    }); });
    candidates.sort(function (a, b) { return Number(b.exactTitle) - Number(a.exactTitle); });
    return Promise.all(candidates.slice(0, 4).map(function (candidate) {
      return http.request(candidate.url, { referer: cfg.site + '/', session: cfg.session }).then(function (html) {
        var identity = catalog.detail(html, candidate.url, meta.kind, meta);
        return identity ? { identity: identity, html: html } : null;
      }).catch(function (error) { warn(error); return null; });
    }));
  }).then(function (results) {
    var confirmed = results.filter(function (result) { return !!result; });
    // A title/year collision is ambiguous without a shared external identifier.
    return confirmed.length === 1 ? confirmed[0] : null;
  });
}

function watchPage(found, meta, cfg, season, episode) {
  var identity = found.identity;
  if (meta.kind === 'movie') {
    var watch = catalog.movieWatchUrl(identity, cfg.site);
    if (!watch) return Promise.resolve(null);
    return http.request(watch, { referer: identity.url, session: cfg.session, responseInfo: true }).then(function (response) {
      // Watch pages have no title metadata, so do not follow a redirect into
      // another title or a generic landing page containing an unrelated player.
      if (String(response.finalUrl || '').split(/[?#]/)[0].replace(/\/+$/, '') !== watch.replace(/\/+$/, '')) return null;
      return { html: response.body, url: watch };
    });
  }
  var seasonPage = catalog.seasonUrl(found.html, identity.url, season);
  if (!seasonPage) return Promise.resolve(null);
  var body = seasonPage === identity.url ? Promise.resolve(found.html) : http.request(seasonPage, { referer: identity.url, session: cfg.session });
  return body.then(function (html) {
    // Season pages must still describe the same confirmed series.
    var confirmed = catalog.detail(html, identity.url, 'tv', meta);
    if (!confirmed || confirmed.url !== identity.url) return null;
    var target = catalog.episodeUrl(html, identity.url, season, episode);
    if (!target) return null;
    return http.request(target, { referer: seasonPage, session: cfg.session }).then(function (episodeHtml) {
      return catalog.validateEpisode(episodeHtml, target, identity, season, episode) ? { html: episodeHtml, url: target } : null;
    });
  });
}

function getStreams(tmdbId, mediaType, season, episode) {
  var kind = mediaType === 'movie' ? 'movie' : /^(?:tv|series|show)$/.test(String(mediaType)) ? 'tv' : '';
  if (!kind || !/^[1-9]\d*$/.test(String(tmdbId))) return Promise.resolve([]);
  if (kind === 'tv' && (!/^\d+$/.test(String(season)) || !/^[1-9]\d*$/.test(String(episode)))) return Promise.resolve([]);
  var cfg = settings();
  if (!cfg.key) {
    console.warn('[DiziAbi TV] TMDB key unavailable. Enter your own key in plugin settings.');
    return Promise.resolve([]);
  }
  return metadata(tmdbId, kind, cfg).then(function (meta) {
    meta.season = Number(season); meta.episode = Number(episode);
    return findTitle(meta, cfg).then(function (found) {
      if (!found) return [];
      return watchPage(found, meta, cfg, season, episode).then(function (page) {
        return page ? player.resolve(page, cfg, meta) : [];
      });
    });
  }).catch(function (error) { warn(error); return []; }).then(function (streams) {
    http.cancel(cfg.session);
    return streams;
  });
}

function onSettings() {
  return Promise.resolve([
    { type: 'header', label: 'DiziAbi TV' },
    { type: 'text', key: 'siteUrl', label: 'Website address', defaultValue: DEFAULT_SITE, description: 'The HTTPS website address. Change this only if DiziAbi moves.' },
    { type: 'text', key: 'tmdbApiKey', label: 'TMDB API key (optional)', isPassword: true, defaultValue: '', description: 'Uses Nuvio\'s key when available. Otherwise enter your own TMDB v3 key or API Read Access Token.' }
  ]);
}

module.exports = { getStreams: getStreams, onSettings: onSettings };

'use strict';
var u = require('./utils');

var MAX_HTML = 1024 * 1024;

function normalize(value) {
  var replacements = { 'İ': 'I', 'ı': 'i', 'Ş': 'S', 'ş': 's', 'Ç': 'C', 'ç': 'c', 'Ğ': 'G', 'ğ': 'g', 'Ö': 'O', 'ö': 'o', 'Ü': 'U', 'ü': 'u', 'Â': 'A', 'â': 'a', 'Î': 'I', 'î': 'i', 'Û': 'U', 'û': 'u', 'É': 'E', 'é': 'e' };
  return u.text(value).replace(/[İıŞşÇçĞğÖöÜüÂâÎîÛûÉé]/g, function (letter) { return replacements[letter]; })
    .toLowerCase().replace(/[̀-ͯ‎‏]/g, '').replace(/[‘’']/g, '').replace(/ё/g, 'е')
    .replace(/[^a-z0-9à-ɏЀ-ӿ぀-ヿ㐀-鿿]+/g, ' ').replace(/\s+/g, ' ').trim();
}

function kindValue(kind) {
  return kind === 'movie' ? 'movie' : /^(?:tv|series|show)$/.test(String(kind)) ? 'tv' : '';
}

function integer(value, minimum) {
  return value != null && /^\d{1,5}$/.test(String(value)) && Number(value) >= minimum ? Number(value) : null;
}

function yearValue(value) {
  var match = /(?:^|\D)((?:18|19|20)\d{2})(?:\D|$)/.exec(String(value == null ? '' : value));
  return match && Number(match[1]) >= 1870 ? Number(match[1]) : 0;
}

function titleList(meta) {
  meta = meta || {};
  var values = [meta.title, meta.originalTitle, meta.turkishTitle, meta.name, meta.original_title, meta.original_name];
  if (Array.isArray(meta.titles)) values = values.concat(meta.titles.slice(0, 16));
  var found = [];
  values.forEach(function (value) {
    if (typeof value !== 'string') return;
    var title = normalize(value);
    if (title && found.indexOf(title) === -1) found.push(title);
  });
  return found;
}

function htmlValue(html) {
  return typeof html === 'string' && html.length <= MAX_HTML ? html.replace(/<!--[\s\S]*?-->/g, '') : '';
}

function localUrl(value, base, keepQuery) {
  value = u.entities(typeof value === 'string' ? value : '');
  if (!value || /[\\\x00-\x20\x7f]/.test(value) || /(?:^|\/)\.{1,2}(?:\/|[?#]|$)/.test(value)) return '';
  var root = u.siteUrl(u.origin(base));
  if (!root) return '';
  var url = u.absolute(value, base);
  if (!/^https:\/\/[a-z0-9.-]+(?::\d+)?\//i.test(url) || !u.sameSite(url, root) || /%(?:00|0[ad]|2f|5c)/i.test(url)) return '';
  url = url.split('#')[0];
  return keepQuery ? url : url.split('?')[0];
}

function route(value, kind, base) {
  var url = localUrl(value, base || value, false);
  if (!url) return null;
  var path = url.slice(u.origin(url).length);
  var match = kind === 'tv' ? /^\/dizi\/([a-z0-9][a-z0-9_-]*)\/?$/i.exec(path) : /^\/([a-z0-9][a-z0-9_-]*)\/?$/i.exec(path);
  if (!match || /^(?:ara|login|register|filmler|diziler|animeler|kesfet|takvim|forum|premium)$/i.test(match[1])) return null;
  return { url: u.origin(url) + (kind === 'tv' ? '/dizi/' : '/') + match[1] + '/', slug: match[1] };
}

function samePage(first, second) {
  return String(first || '').replace(/\/+$/, '').toLowerCase() === String(second || '').replace(/\/+$/, '').toLowerCase();
}

function parseSuggestions(data, base, kind, meta) {
  kind = kindValue(kind);
  if (!kind || !u.siteUrl(u.origin(base))) return [];
  if (typeof data === 'string') {
    if (data.length > MAX_HTML) return [];
    try { data = JSON.parse(data); } catch (ignore) { return []; }
  }
  if (!data || typeof data !== 'object' || Array.isArray(data)) return [];
  var records = data[kind === 'movie' ? 'movies' : 'series'];
  if (!Array.isArray(records)) return [];
  var titles = titleList(meta);
  var wantedYear = yearValue(meta && meta.year);
  var seen = {};
  return records.slice(0, 64).map(function (item, index) {
    if (!item || typeof item !== 'object' || kindValue(item.type) !== kind || typeof item.title !== 'string') return null;
    var target = route(item.url, kind, base);
    var year = yearValue(item.meta);
    var title = u.text(item.title);
    if (!target || !title || title.length > 300 || !year || (wantedYear && year !== wantedYear) || seen[target.url]) return null;
    seen[target.url] = true;
    var exact = titles.indexOf(normalize(title)) !== -1;
    var result = { url: target.url, title: title, type: kind, year: year, exactTitle: exact };
    if (integer(item.id, 1) !== null) result.id = Number(item.id);
    return { item: result, index: index, score: exact ? 1 : 0 };
  }).filter(Boolean).sort(function (a, b) { return b.score - a.score || a.index - b.index; }).slice(0, 12).map(function (entry) { return entry.item; });
}

function nodes(html) {
  var results = [];
  var scripts = /<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi;
  var match;
  var count = 0;
  var visited = 0;
  html = htmlValue(html);
  function walk(value, depth) {
    if (!value || typeof value !== 'object' || depth > 6 || visited >= 128) return;
    visited++;
    if (Array.isArray(value)) {
      value.slice(0, 128).forEach(function (entry) { walk(entry, depth + 1); });
      return;
    }
    if (typeof value['@type'] === 'string' || Array.isArray(value['@type'])) results.push(value);
    if (value['@graph']) walk(value['@graph'], depth + 1);
  }
  while ((match = scripts.exec(html)) !== null && count < 12 && visited < 128) {
    if (u.attr(match[1], 'type').toLowerCase() !== 'application/ld+json') continue;
    count++;
    if (match[2].length > 256 * 1024) continue;
    try { walk(JSON.parse(match[2]), 0); } catch (ignore) { /* Invalid data is not executable code. */ }
  }
  return results;
}

function hasType(node, expected) {
  var types = Array.isArray(node['@type']) ? node['@type'] : [node['@type']];
  return types.indexOf(expected) !== -1;
}

function watchTarget(node, pageUrl) {
  var actions = Array.isArray(node.potentialAction) ? node.potentialAction : [node.potentialAction];
  var target = '';
  actions.slice(0, 8).forEach(function (action) {
    if (!action || !hasType(action, 'WatchAction') || typeof action.target !== 'string') return;
    var url = localUrl(action.target, pageUrl, true);
    if (url && !/[?#]/.test(url) && samePage(url, pageUrl + 'izle/')) target = url.replace(/\/?$/, '/');
  });
  return target;
}

function detail(html, url, kind, meta) {
  kind = kindValue(kind);
  var expected = route(url, kind, url);
  var titles = titleList(meta);
  var wantedYear = yearValue(meta && meta.year);
  if (!kind || !expected || !titles.length || !wantedYear) return null;
  var found = [];
  nodes(html).forEach(function (node) {
    if (!hasType(node, kind === 'movie' ? 'Movie' : 'TVSeries')) return;
    var canonical = route(node.url, kind, expected.url);
    var year = yearValue(kind === 'movie' ? node.datePublished : node.startDate);
    var name = typeof node.name === 'string' ? u.text(node.name) : '';
    var alternate = typeof node.alternateName === 'string' ? u.text(node.alternateName) : '';
    if (!canonical || !samePage(canonical.url, expected.url) || year !== wantedYear || !name || (titles.indexOf(normalize(name)) === -1 && titles.indexOf(normalize(alternate)) === -1)) return;
    found.push({ url: canonical.url, type: kind, title: name, alternateTitle: alternate, year: year, slug: canonical.slug, watchUrl: kind === 'movie' ? watchTarget(node, canonical.url) : '' });
  });
  // More than one identity is ambiguous, even if a later node looks plausible.
  return found.length === 1 ? found[0] : null;
}

function movieWatchUrl(item, base) {
  if (!item || item.type !== 'movie') return '';
  var page = route(item.url, 'movie', base || item.url);
  var url = page && localUrl(item.watchUrl, page.url, true);
  return url && !/[?#]/.test(url) && samePage(url, page.url + 'izle/') ? url.replace(/\/?$/, '/') : '';
}

function anchorUrls(html, base) {
  html = htmlValue(html).replace(/<script\b[^>]*>[\s\S]*?<\/script\s*>/gi, '').replace(/<style\b[^>]*>[\s\S]*?<\/style\s*>/gi, '');
  var anchors = /<a\b([^>]*)>/gi;
  var match;
  var urls = [];
  while ((match = anchors.exec(html)) !== null && urls.length < 2048) {
    var url = localUrl(u.attr(match[1], 'href'), base, true);
    if (url) urls.push(url);
  }
  return urls;
}

function seasonUrl(html, seriesUrl, season) {
  var series = route(seriesUrl, 'tv', seriesUrl);
  var number = integer(season, 0);
  if (!series || number === null) return '';
  var found = '';
  anchorUrls(html, series.url).some(function (url) {
    var parts = url.split('?');
    var query = /^sezon=(\d{1,5})$/.exec(parts[1] || '');
    if (parts.length === 2 && samePage(parts[0], series.url) && query && Number(query[1]) === number) { found = url; return true; }
    return false;
  });
  // The base detail page can itself be the published first-season listing.
  if (!found && number === 1 && episodeUrl(html, series.url, 1, 1)) return series.url;
  return found;
}

function episodeUrl(html, seriesUrl, season, episode) {
  var series = route(seriesUrl, 'tv', seriesUrl);
  var wantedSeason = integer(season, 0);
  var wantedEpisode = integer(episode, 1);
  if (!series || wantedSeason === null || wantedEpisode === null) return '';
  var found = '';
  anchorUrls(html, series.url).some(function (url) {
    if (/[?#]/.test(url)) return false;
    var match = /^\/bolum\/([a-z0-9][a-z0-9_-]*)-(\d{1,5})-sezon-(\d{1,5})-bolum\/?$/i.exec(url.slice(u.origin(url).length));
    if (match && match[1].toLowerCase() === series.slug.toLowerCase() && Number(match[2]) === wantedSeason && Number(match[3]) === wantedEpisode) { found = url.replace(/\/?$/, '/'); return true; }
    return false;
  });
  return found;
}

function validateEpisode(html, url, series, season, episode) {
  var seriesUrl = typeof series === 'string' ? series : series && series.url;
  var parent = route(seriesUrl, 'tv', seriesUrl);
  var target = parent && localUrl(url, parent.url, true);
  var wantedSeason = integer(season, 0);
  var wantedEpisode = integer(episode, 1);
  if (!parent || !target || /[?#]/.test(target) || wantedSeason === null || wantedEpisode === null) return false;
  var expected = episodeUrl('<a href="' + target + '">episode</a>', parent.url, wantedSeason, wantedEpisode);
  if (!expected) return false;
  var titles = typeof series === 'object' ? titleList({ title: series.title, originalTitle: series.alternateTitle }) : [];
  var matching = nodes(html).filter(function (node) {
    if (!hasType(node, 'TVEpisode') || !node.partOfSeason || !node.partOfSeries) return false;
    var canonical = localUrl(node.url, target, true);
    var actualParent = route(node.partOfSeries.url, 'tv', parent.url);
    return canonical && !/[?#]/.test(canonical) && samePage(canonical, target) && actualParent && samePage(actualParent.url, parent.url) &&
      integer(node.episodeNumber, 1) === wantedEpisode && integer(node.partOfSeason.seasonNumber, 0) === wantedSeason &&
      (!titles.length || titles.indexOf(normalize(node.partOfSeries.name)) !== -1);
  });
  return matching.length === 1;
}

module.exports = { normalize: normalize, parseSuggestions: parseSuggestions, detail: detail, movieWatchUrl: movieWatchUrl, seasonUrl: seasonUrl, episodeUrl: episodeUrl, validateEpisode: validateEpisode };

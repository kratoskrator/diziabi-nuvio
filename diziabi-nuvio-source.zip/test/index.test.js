'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const catalog = require('../src/catalog');
const utils = require('../src/utils');
const indexSource = fs.readFileSync(require.resolve('../src/index'), 'utf8');
const site = 'https://www.diziabi.net';
const movie = { '@type':'Movie', name:'Example Movie', alternateName:'Example Movie', datePublished:'2019-03-29', url:site+'/example-movie/', potentialAction:{'@type':'WatchAction',target:site+'/example-movie/izle/'} };
const series = { '@type':'TVSeries', name:'Example Series', alternateName:'Example Series', startDate:'2008-09-23', url:site+'/dizi/example-series/' };
const episode = { '@type':'TVEpisode', episodeNumber:2, partOfSeason:{seasonNumber:2}, partOfSeries:{name:'Example Series',url:series.url}, url:site+'/bolum/example-series-2-sezon-2-bolum/' };
function ld(value) { return '<script type="application/ld+json">'+JSON.stringify(value)+'</script>'; }

function harness(routes, options={}) {
  const requests=[], players=[], warnings=[];
  const context=vm.createContext({
    module:{exports:{}}, SCRAPER_SETTINGS:options.settings||{}, TMDB_API_KEY:options.noKey?'':'fixture-key',
    console:{warn:message=>warnings.push(message)},
    require:name=>({
      './utils':utils, './catalog':catalog,
      './http':{session:()=>({deadline:Date.now()+50000,blocked:{}}),cancel:state=>{state.cancelled=true;},request:(url,init)=>{
        requests.push({url,init});
        if (!Object.hasOwn(routes,url)) return Promise.reject(new Error('Unexpected fixture request '+url));
        const reply=routes[url];
        return reply instanceof Error ? Promise.reject(reply) : Promise.resolve(reply);
      }},
      './player':{resolve:(page,cfg,meta)=>{players.push({page,cfg,meta});return Promise.resolve([{url:'https://media.test/master.m3u8',type:'hls',quality:'720p'}]);}}
    })[name]
  });
  vm.runInContext(indexSource,context,{timeout:1000});
  return {api:context.module.exports,requests,players,warnings};
}
function movieRoutes() {
  return {
    'https://api.themoviedb.org/3/movie/1?language=tr-TR&api_key=fixture-key':{id:1,title:'Example Movie',original_title:'Example Movie',release_date:'2019-03-29'},
    [site+'/ara/oneri?q=Example%20Movie']:{movies:[{type:'movie',id:999,title:'Example Movie',meta:'Film · 2019',url:movie.url}]},
    [movie.url]:ld(movie),
    [movie.url+'izle/']:{body:'<div data-pv="fixture-movie"></div>',finalUrl:movie.url+'izle/'}
  };
}
function tvRoutes() {
  const page=ld(series)+'<a href="?sezon=1">1</a><a href="?sezon=2">2</a>';
  return {
    'https://api.themoviedb.org/3/tv/2?language=tr-TR&api_key=fixture-key':{id:2,name:'Example Series',original_name:'Example Series',first_air_date:'2008-09-23'},
    [site+'/ara/oneri?q=Example%20Series']:{series:[{type:'series',title:'Example Series',meta:'Dizi · 2008',url:series.url}]},
    [series.url]:page,
    [series.url+'?sezon=2']:page+'<a href="'+site+'/bolum/example-series-2-sezon-1-bolum/">1</a><a href="'+episode.url+'">2</a>',
    [episode.url]:ld(episode)+'<div data-pv="fixture-episode"></div>'
  };
}

test('movie lookup confirms typed title/year before following its published watch action',async()=>{
  const h=harness(movieRoutes());
  const streams=await h.api.getStreams(1,'movie');
  assert.equal(streams.length,1);
  assert.equal(h.players[0].page.url,movie.url+'izle/');
  assert.equal(h.players[0].meta.kind,'movie');
  assert.equal(h.requests.length,4);
  assert.ok(h.requests.every(req=>req.init.session===h.players[0].cfg.session));
  assert.equal(h.players[0].cfg.session.cancelled,true);
});

test('later-season series lookup follows a published season and validates the exact episode',async()=>{
  const h=harness(tvRoutes());
  assert.equal((await h.api.getStreams(2,'tv',2,2)).length,1);
  assert.equal(h.players[0].page.url,episode.url);
  assert.equal(h.players[0].meta.season,2);
  assert.equal(h.players[0].meta.episode,2);
  assert.equal(h.requests.length,5);
});

test('missing or mislabeled episode never falls back to a different episode',async()=>{
  for (const mutate of [
    routes=>{routes[series.url+'?sezon=2']=ld(series)+'<a href="/bolum/example-series-2-sezon-1-bolum/">1</a>';},
    routes=>{routes[episode.url]=ld({...episode,episodeNumber:1});},
    routes=>{routes[series.url+'?sezon=2']=ld({...series,name:'Different Series',alternateName:'Different Series'});}
  ]) {
    const routes=tvRoutes();mutate(routes);const h=harness(routes);
    assert.equal((await h.api.getStreams(2,'series',2,2)).length,0);
    assert.equal(h.players.length,0);
  }
});

test('a matching search result with the wrong detail identity is rejected',async()=>{
  const routes=movieRoutes();routes[movie.url]=ld({...movie,datePublished:'2020-03-29'});
  const h=harness(routes);
  assert.equal((await h.api.getStreams(1,'movie')).length,0);
  assert.equal(h.players.length,0);
  assert.ok(!h.requests.some(req=>req.url===movie.url+'izle/'));
});

test('a movie watch redirect into an unrelated page is rejected before player extraction',async()=>{
  const routes=movieRoutes();
  routes[movie.url+'izle/']={body:'<div data-pv="unrelated-movie"></div>',finalUrl:site+'/another-movie/izle/'};
  const h=harness(routes);
  assert.equal((await h.api.getStreams(1,'movie')).length,0);
  assert.equal(h.players.length,0);
});

test('ambiguous duplicate title/year identities produce no source',async()=>{
  const routes=movieRoutes(), other=site+'/example-movie-other/';
  routes[site+'/ara/oneri?q=Example%20Movie'].movies.push({type:'movie',title:'Example Movie',meta:'Film · 2019',url:other});
  routes[other]=ld({...movie,url:other,potentialAction:{'@type':'WatchAction',target:other+'izle/'}});
  const h=harness(routes);
  assert.equal((await h.api.getStreams(1,'movie')).length,0);
  assert.equal(h.players.length,0);
});

test('title-detail work is capped at four candidates even when suggestions are broad',async()=>{
  const routes=movieRoutes();
  routes[site+'/ara/oneri?q=Example%20Movie'].movies=Array.from({length:40},(_,i)=>({type:'movie',title:'Unrelated '+i,meta:'Film · 2019',url:site+'/unrelated-'+i+'/'}));
  for(let i=0;i<40;i++) routes[site+'/unrelated-'+i+'/']=ld({...movie,name:'Unrelated '+i,alternateName:'Unrelated '+i,url:site+'/unrelated-'+i+'/'});
  const h=harness(routes);
  assert.equal((await h.api.getStreams(1,'movie')).length,0);
  assert.equal(h.requests.length,6);
});

test('missing key, invalid IDs and unsupported types make no network request',async()=>{
  const h=harness({}, {noKey:true});
  assert.equal((await h.api.getStreams(1,'movie')).length,0);
  const keyed=harness({});
  for(const args of [['tt123','movie'],[0,'movie'],[1,'live'],[1,'tv',1,0],[1,'tv','2x',1]]) assert.equal((await keyed.api.getStreams(...args)).length,0);
  assert.equal(h.requests.length+keyed.requests.length,0);
  assert.match(h.warnings[0],/TMDB/);
});

test('own TMDB bearer token is only sent to TMDB and never printed in an error',async()=>{
  const token='fixture-private-token-'.repeat(4),url='https://api.themoviedb.org/3/movie/1?language=tr-TR';
  const h=harness({[url]:new Error('private '+token)},{settings:{tmdbApiKey:token}});
  assert.equal((await h.api.getStreams(1,'movie')).length,0);
  assert.equal(h.requests.length,1);
  assert.equal(h.requests[0].init.bearer,token);
  assert.ok(!h.warnings.join('').includes(token));
  assert.equal(h.requests[0].init.session.cancelled,true);
});

test('settings expose website and a masked optional TMDB key',async()=>{
  const settings=await harness({}).api.onSettings();
  assert.equal(settings.find(item=>item.key==='siteUrl').defaultValue,site);
  assert.equal(settings.find(item=>item.key==='tmdbApiKey').isPassword,true);
});

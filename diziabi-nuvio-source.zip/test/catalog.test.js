'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const c = require('../src/catalog');
const base = 'https://catalog.example';
const movieUrl = base + '/yerel-film/';
const seriesUrl = base + '/dizi/ornek-dizi/';
const movieMeta = { title: 'Original Film', year: 2024 };
const tvMeta = { title: 'Örnek Dizi', originalTitle: 'Example Show', year: 2023 };
const ld = node => '<script type="application/ld+json">' + JSON.stringify(node) + '</script>';
const graph = nodes => ld({ '@context': 'https://schema.org', '@graph': nodes });
const movie = extra => Object.assign({ '@type': 'Movie', name: 'Yerel Film', alternateName: 'Original Film', url: movieUrl, datePublished: '2024-05-02', potentialAction: { '@type': 'WatchAction', target: movieUrl + 'izle/' } }, extra);
const show = extra => Object.assign({ '@type': 'TVSeries', name: 'Örnek Dizi', alternateName: 'Example Show', url: seriesUrl, startDate: '2023-01-02' }, extra);
const episodeUrl = base + '/bolum/ornek-dizi-2-sezon-3-bolum/';
const episode = extra => Object.assign({ '@type': 'TVEpisode', url: episodeUrl, episodeNumber: 3, partOfSeason: { '@type': 'TVSeason', seasonNumber: 2 }, partOfSeries: { '@type': 'TVSeries', name: 'Örnek Dizi', url: seriesUrl } }, extra);
const suggestion = extra => Object.assign({ id: 9, type: 'movie', title: 'Original Film', url: movieUrl, meta: 'Film · 2024' }, extra);

test('normalizes Turkish dotted and dotless I, accents, combining marks and punctuation without truncating words', () => {
  assert.equal(c.normalize('İŞLER: Çığlık, Ölü GÜNÜ!'), 'isler ciglik olu gunu');
  assert.equal(c.normalize('Is\u0327ler &amp; O’Brian'), 'isler obrian');
  assert.equal(c.normalize('Dizi 2'), 'dizi 2');
  assert.notEqual(c.normalize('A New Show'), c.normalize('New Show'));
});

test('ranks exact suggestion titles first but retains translated same-year candidates for detail confirmation', () => {
  const rows = [suggestion({ id: 1, title: 'Başka Çeviri', url: '/translated/' }), suggestion({ id: 2 }), suggestion({ id: 3, title: 'Original Film Returns', url: '/sequel/', meta: 'Film · 2025' })];
  const result = c.parseSuggestions(JSON.stringify({ movies: rows }), base, 'movie', movieMeta);
  assert.deepEqual(result.map(row => [row.id, row.exactTitle]), [[2, true], [1, false]]);
});

test('does not mix movie, TV, anime-series or actor search groups', () => {
  const data = { movies: [suggestion()], series: [suggestion({ type: 'series', title: 'Örnek Dizi', url: '/dizi/ornek-dizi/', meta: 'Anime · 2023' }), suggestion()], people: [suggestion({ type: 'series' })] };
  const rows = c.parseSuggestions(data, base, 'tv', tvMeta);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].url, seriesUrl);
  assert.equal(rows[0].type, 'tv');
  assert.equal(c.parseSuggestions(data, base, 'movie', movieMeta).length, 1);
  assert.deepEqual(c.parseSuggestions(data, base, 'actor', movieMeta), []);
});

test('rejects external, credential, script, encoded separator and traversal suggestion URLs', () => {
  const urls = ['https://elsewhere.example/a/', '//elsewhere.example/a/', 'https://catalog.example@elsewhere.example/a/', 'javascript:alert(1)', '/a\\b/', '/%2fhidden/', '/../a/', '/a/%5cb/'];
  assert.deepEqual(c.parseSuggestions({ movies: urls.map(url => suggestion({ url })) }, base, 'movie', movieMeta), []);
});

test('deduplicates suggestion URLs, rejects missing years and limits broad searches', () => {
  const data = { movies: [suggestion(), suggestion(), suggestion({ url: '/unknown-year/', meta: 'Film' })].concat(Array.from({ length: 70 }, (_, i) => suggestion({ url: '/film-' + i + '/' }))) };
  const rows = c.parseSuggestions(data, base, 'movie', movieMeta);
  assert.equal(rows.length, 12);
  assert.equal(rows.filter(row => row.url === movieUrl).length, 1);
  assert.deepEqual(c.parseSuggestions('{broken', base, 'movie', movieMeta), []);
  assert.deepEqual(c.parseSuggestions('x'.repeat(1024 * 1024 + 1), base, 'movie', movieMeta), []);
});

test('confirms a localized Movie through the exact original title and publication year', () => {
  const result = c.detail(graph([{ '@type': 'WebSite', name: 'Site' }, movie()]), movieUrl, 'movie', movieMeta);
  assert.deepEqual(result, { url: movieUrl, type: 'movie', title: 'Yerel Film', alternateTitle: 'Original Film', year: 2024, slug: 'yerel-film', watchUrl: movieUrl + 'izle/' });
  assert.equal(c.movieWatchUrl(result, base), movieUrl + 'izle/');
});

test('requires exact title, year and requested typed identity rather than a trailer or nearby remake', () => {
  assert.equal(c.detail(ld(movie({ alternateName: 'Original Film Returns' })), movieUrl, 'movie', movieMeta), null);
  assert.equal(c.detail(ld(movie({ datePublished: '2023-05-02' })), movieUrl, 'movie', movieMeta), null);
  assert.equal(c.detail(ld(movie({ '@type': 'VideoObject' })), movieUrl, 'movie', movieMeta), null);
  assert.equal(c.detail(ld(movie()), movieUrl, 'movie', { title: 'Original Film' }), null);
  assert.equal(c.detail(ld(movie()), movieUrl, 'tv', movieMeta), null);
});

test('rejects a correct title when its canonical points at a different page or origin', () => {
  assert.equal(c.detail(ld(movie({ url: '/other/' })), movieUrl, 'movie', movieMeta), null);
  assert.equal(c.detail(ld(movie({ url: 'https://elsewhere.example/yerel-film/' })), movieUrl, 'movie', movieMeta), null);
  assert.equal(c.detail(ld(movie({ url: 'https://catalog.example@elsewhere.example/yerel-film/' })), movieUrl, 'movie', movieMeta), null);
});

test('does not execute ordinary scripts or accept commented, malformed or ambiguous JSON-LD', () => {
  global.__diziabiExecuted = false;
  const fake = '<script>global.__diziabiExecuted=true; ' + JSON.stringify(movie()) + '</script>';
  assert.equal(c.detail(fake, movieUrl, 'movie', movieMeta), null);
  assert.equal(global.__diziabiExecuted, false);
  delete global.__diziabiExecuted;
  assert.equal(c.detail('<!--' + ld(movie()) + '-->', movieUrl, 'movie', movieMeta), null);
  assert.equal(c.detail('<script type="application/ld+json">not json</script>', movieUrl, 'movie', movieMeta), null);
  assert.equal(c.detail(graph([movie(), movie()]), movieUrl, 'movie', movieMeta), null);
});

test('bounds JSON-LD nesting and excludes arbitrary nested parent-series nodes', () => {
  let deep = movie();
  for (let i = 0; i < 10; i++) deep = { '@graph': [deep] };
  assert.equal(c.detail(ld(deep), movieUrl, 'movie', movieMeta), null);
  assert.equal(c.detail(ld({ '@type': 'TVEpisode', partOfSeries: show() }), seriesUrl, 'tv', tvMeta), null);
  assert.equal(c.detail(ld(movie()) + ' '.repeat(1024 * 1024), movieUrl, 'movie', movieMeta), null);
});

test('only accepts the published same-title WatchAction route and ignores trailer URLs', () => {
  const variants = [undefined, { '@type': 'WatchAction', target: 'https://elsewhere.example/video/' }, { '@type': 'WatchAction', target: '/different/izle/' }, { '@type': 'WatchAction', target: movieUrl + 'izle/?token=x' }, { '@type': 'PlayAction', target: movieUrl + 'izle/' }];
  variants.forEach(potentialAction => {
    const result = c.detail(ld(movie({ potentialAction, trailer: { embedUrl: 'https://video.example/trailer' } })), movieUrl, 'movie', movieMeta);
    assert.equal(c.movieWatchUrl(result, base), '');
  });
  assert.equal(c.movieWatchUrl({ type: 'movie', url: movieUrl, watchUrl: '/different/izle/' }, base), '');
});

test('confirms TV series identity on a season page whose JSON-LD uses canonical base URL', () => {
  const result = c.detail(ld(show()), seriesUrl, 'series', tvMeta);
  assert.equal(result.url, seriesUrl);
  assert.equal(result.year, 2023);
  assert.equal(result.watchUrl, '');
});

test('selects only an explicitly published requested-season link from the same series', () => {
  const html = '<a href="/dizi/other/?sezon=2#bolumler">Other</a><a href="?sezon=12#bolumler">Twelve</a><a href="?sezon=2#bolumler">Two</a>';
  assert.equal(c.seasonUrl(html, seriesUrl, 2), seriesUrl + '?sezon=2');
  assert.equal(c.seasonUrl(html, seriesUrl, 3), '');
  assert.equal(c.seasonUrl('<a href="?sezon=2&amp;next=elsewhere">Not the published season route</a>', seriesUrl, 2), '');
});

test('uses first-season base page only when a genuine first-episode link is present', () => {
  assert.equal(c.seasonUrl('<a href="/bolum/ornek-dizi-1-sezon-1-bolum/">One</a>', seriesUrl, 1), seriesUrl);
  assert.equal(c.seasonUrl('<a href="/bolum/other-1-sezon-1-bolum/">Other</a>', seriesUrl, 1), '');
  assert.equal(c.seasonUrl('<p>No episodes</p>', seriesUrl, 1), '');
  assert.equal(c.seasonUrl('<!--<a href="?sezon=1">Hidden</a>-->', seriesUrl, 1), '');
});

test('matches the exact published episode and ignores first-episode shortcuts and recommendations', () => {
  const html = '<a href="/bolum/ornek-dizi-1-sezon-1-bolum/">First</a><a href="/bolum/other-2-sezon-3-bolum/">Other</a><a href="/bolum/ornek-dizi-2-sezon-13-bolum/">Thirteen</a><a href="' + episodeUrl + '">Exact</a>';
  assert.equal(c.episodeUrl(html, seriesUrl, 2, 3), episodeUrl);
  assert.equal(c.episodeUrl(html, seriesUrl, 2, 4), '');
  assert.equal(c.episodeUrl(html, seriesUrl, null, 3), '');
});

test('does not synthesize absent episodes or read anchor lookalikes in scripts, styles and comments', () => {
  const anchor = '<a href="' + episodeUrl + '">Fake</a>';
  assert.equal(c.episodeUrl('<script>var fake=' + JSON.stringify(anchor) + '</script><!--' + anchor + '--><style>' + anchor + '</style>', seriesUrl, 2, 3), '');
  assert.equal(c.episodeUrl('<a href="https://elsewhere.example/bolum/ornek-dizi-2-sezon-3-bolum/">External</a>', seriesUrl, 2, 3), '');
  assert.equal(c.episodeUrl('<a href="' + episodeUrl + '?next=x">Query</a>', seriesUrl, 2, 3), '');
});

test('validates canonical episode, numeric season/episode and exact parent series identity', () => {
  const identity = c.detail(ld(show()), seriesUrl, 'tv', tvMeta);
  assert.equal(c.validateEpisode(ld(episode()), episodeUrl, identity, 2, 3), true);
  assert.equal(c.validateEpisode(ld(episode()), episodeUrl, seriesUrl, 2, 3), true);
  assert.equal(c.validateEpisode(ld(episode({ episodeNumber: 4 })), episodeUrl, identity, 2, 3), false);
  assert.equal(c.validateEpisode(ld(episode({ partOfSeason: { seasonNumber: 3 } })), episodeUrl, identity, 2, 3), false);
  assert.equal(c.validateEpisode(ld(episode({ url: '/bolum/ornek-dizi-2-sezon-4-bolum/' })), episodeUrl, identity, 2, 3), false);
});

test('rejects unrelated or ambiguous episode JSON-LD even when season numbers match', () => {
  const identity = c.detail(ld(show()), seriesUrl, 'tv', tvMeta);
  assert.equal(c.validateEpisode(ld(episode({ partOfSeries: { name: 'Other', url: seriesUrl } })), episodeUrl, identity, 2, 3), false);
  assert.equal(c.validateEpisode(ld(episode({ partOfSeries: { name: 'Örnek Dizi', url: '/dizi/other/' } })), episodeUrl, identity, 2, 3), false);
  assert.equal(c.validateEpisode(graph([episode(), episode()]), episodeUrl, identity, 2, 3), false);
  assert.equal(c.validateEpisode(ld(episode()), base + '/bolum/other-2-sezon-3-bolum/', identity, 2, 3), false);
});

test('supports an explicitly published season-zero special while rejecting episode zero', () => {
  const specialUrl = base + '/bolum/ornek-dizi-0-sezon-1-bolum/';
  const special = episode({ url: specialUrl, episodeNumber: 1, partOfSeason: { seasonNumber: 0 } });
  assert.equal(c.episodeUrl('<a href="' + specialUrl + '">Special</a>', seriesUrl, 0, 1), specialUrl);
  assert.equal(c.validateEpisode(ld(special), specialUrl, seriesUrl, 0, 1), true);
  assert.equal(c.episodeUrl('<a href="/bolum/ornek-dizi-0-sezon-0-bolum/">Zero</a>', seriesUrl, 0, 0), '');
});

'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const utils = require('../src/utils');
const media = require('../src/media');
const source = fs.readFileSync(path.join(__dirname, '../src/player.js'), 'utf8');
const SITE = 'https://www.diziabi.net';
const HOST = 'https://play2.pilavyerplay.top';
const FRAME = HOST + '/assets/js/s.php?s=fixture_slug_22';
const STREAM = HOST + '/api/stream.php?v=fixture&token=issued-public-fixture';
const CHILD = HOST + '/api/stream.php?v=fixture&p=720&token=issued-public-fixture';
const page = { url: SITE + '/bolum/fixture-1-sezon-2-bolum/', html: '<div data-pv="fixture_slug_22"></div><script src="' + HOST + '/assets/js/core.js" async></script>' };
const meta = { title: 'Fixture Show', kind: 'tv', season: 1, episode: 2 };
const config = { title: 'Fixture.Show.S01E02.2160p.WEB', stream: STREAM, dur: 600, audios: [{lang:'tr',label:'Türkçe Dublaj'},{lang:'en',label:'Original'}], subs: [{src:HOST+'/api/sub.php?v=fixture&sid=tr&token=issued-public-fixture',lang:'tr',label:'Türkçe Altyazı'}] };
const MASTER = '#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="dual",LANGUAGE="tr",URI="stream.php?v=fixture&p=audio"\n#EXT-X-STREAM-INF:RESOLUTION=1280x720,CODECS="avc1.4d401f,mp4a.40.2",AUDIO="dual"\nstream.php?v=fixture&p=720&token=issued-public-fixture\n';
const VOD = '#EXTM3U\n#EXT-X-PLAYLIST-TYPE:VOD\n#EXT-X-KEY:METHOD=AES-128,URI="key.php?v=fixture&token=issued-public-fixture"\n#EXTINF:600,\nhttps://pilavyer1.top/cdn/fixture/00000.txt\n#EXT-X-ENDLIST\n';
function playerHTML(value = config) { return '<script>window.__PLAYER__ = ' + JSON.stringify(value) + ';</script>'; }
function harness(handler) {
  const calls = [];
  const session = {deadline:Date.now()+50000,blocked:{}};
  const context = vm.createContext({
    module:{exports:{}},
    require:name=>({ './utils':utils, './media':media, './http':{USER_AGENT:'FixtureTV',session:()=>session,request:(url,options)=>{calls.push({url,options});return Promise.resolve().then(()=>handler(url,options,calls.length));}} })[name]
  });
  vm.runInContext(source, context, {timeout:1000});
  return {player:context.module.exports,calls,session,context};
}
function routes(changes = {}) {
  return (url, options) => {
    if (url === FRAME) return {body:changes.html===undefined?playerHTML(changes.config||config):changes.html,finalUrl:changes.frameURL||url};
    if (url === STREAM) return {body:changes.master===undefined?MASTER:changes.master,finalUrl:changes.masterURL||url};
    if (url === CHILD) return {body:changes.child===undefined?VOD:changes.child,finalUrl:changes.childURL||url};
    throw new Error('Unexpected request: '+url);
  };
}
function plain(value) { return JSON.parse(JSON.stringify(value)); }

test('TV extraction uses strict static JSON, actual HLS quality, dual audio and safe subtitle context', async () => {
  const h=harness(routes());const result=await h.player.resolve(page,{session:h.session},meta);
  assert.equal(result.length,1);assert.equal(result[0].url,STREAM);assert.equal(result[0].type,'hls');
  assert.equal(result[0].quality,'720p');assert.match(result[0].title,/Türkçe Dublaj \/ Original/);assert.match(result[0].title,/H\.264 \+ AAC/);
  assert.equal(result[0].subtitles[0].language,'tr');assert.equal(result[0].subtitles[0].headers.Referer,HOST+'/');
  assert.deepEqual(h.calls.map(c=>c.url),[FRAME,STREAM,CHILD]);
  assert.equal(h.calls[0].options.referer,SITE+'/');assert.equal(h.calls[1].options.headers.Origin,HOST);
  assert.ok(h.calls.every(c=>c.options.session===h.session));
  assert.equal(vm.runInContext('typeof URL+","+typeof document+","+typeof setTimeout',h.context),'undefined,undefined,undefined');
  assert.ok(h.calls.every(c=>!c.options.headers||!('Cookie' in c.options.headers)&&!('Authorization' in c.options.headers)));
});
test('public data-pv loader is parsed without script execution and duplicate frames are bounded', () => {
  const h=harness(()=>{});const html='<!--<div data-pv="ignored_slug"></div>-->'+page.html+page.html+Array.from({length:8},(_,i)=>'<div data-pv="fixture_extra_'+i+'"></div>').join('');
  const result=h.player.frames(html,page.url);assert.equal(result.length,4);assert.equal(result[0],FRAME);assert.ok(result.every(v=>v.startsWith(HOST)));
});
test('the loader must belong to the current supported public player and not an arbitrary script host', () => {
  const h=harness(()=>{});assert.deepEqual(plain(h.player.frames(page.html.replace(HOST,'https://evil.test'),page.url)),[]);
  assert.deepEqual(plain(h.player.frames(page.html.replace('fixture_slug_22','../../private'),page.url)),[]);
});
test('normal explicit player iframe is supported but YouTube and javascript iframe sources are excluded', () => {
  const h=harness(()=>{});assert.deepEqual(plain(h.player.frames('<iframe src="'+FRAME+'"></iframe><iframe src="https://youtube.com/embed/x"></iframe><iframe src="javascript:alert(1)"></iframe>',page.url)),[FRAME]);
});
test('configuration parser accepts JSON escapes and nested subtitle data while rejecting executable expressions', () => {
  const h=harness(()=>{});assert.equal(h.player.configuration(playerHTML()).stream,STREAM);
  assert.equal(h.player.configuration('<script>window.__PLAYER__ = {stream: "x"};</script>'),null);
  assert.equal(h.player.configuration('<script>window.__PLAYER__ = '+JSON.stringify(config)+';globalThis.executed=true;</script>'),null);
  assert.equal(h.player.configuration('<script>window.__PLAYER__ = JSON.parse("{}");</script>'),null);
  assert.equal(h.player.configuration('<script src="remote.js">window.__PLAYER__ = '+JSON.stringify(config)+';</script>'),null);
  assert.equal(vm.runInContext('typeof executed',h.context),'undefined');
});
test('an episode filename explicitly pointing at another episode is rejected before any media request', async () => {
  const h=harness(routes({config:Object.assign({},config,{title:'Fixture.Show.S01E03.1080p'})}));
  assert.equal((await h.player.resolve(page,{},meta)).length,0);assert.equal(h.calls.length,1);
});
test('a movie does not inherit episode filtering and filename quality never overrides manifest quality', async () => {
  const h=harness(routes());const result=await h.player.resolve(page,{}, {title:'Fixture Movie',kind:'movie'});
  assert.equal(result[0].quality,'720p');assert.doesNotMatch(result[0].title,/Sundefined|2160p/);
});
test('stream and subtitle addresses are constrained to the issuing player host', async () => {
  const bad=harness(routes({config:Object.assign({},config,{stream:'https://evil.test/api/stream.php?token=fixture'})}));
  assert.equal((await bad.player.resolve(page,{},meta)).length,0);assert.equal(bad.calls.length,1);
  const good=harness(routes({config:Object.assign({},config,{subs:config.subs.concat([{src:'https://evil.test/api/sub.php?token=fixture',lang:'tr'},{src:'javascript:alert(1)',lang:'tr'}])})}));
  const result=await good.player.resolve(page,{},meta);assert.equal(result[0].subtitles.length,1);
});
test('HTML errors and malformed master playlists cannot be surfaced as a playback source', async () => {
  for(const master of ['<html>verification</html>','#EXTM3U\n<html>error</html>','#EXTM3U\n#EXT-X-STREAM-INF:RESOLUTION=1920x1080\n']){
    const h=harness(routes({master}));assert.equal((await h.player.resolve(page,{},meta)).length,0);
  }
});
test('DRM in a child playlist is rejected while ordinary AES128 HLS is allowed', async () => {
  for(const child of [VOD.replace('METHOD=AES-128','METHOD=SAMPLE-AES'),VOD.replace('METHOD=AES-128','METHOD=AES-128,KEYFORMAT="com.apple.streamingkeydelivery"')]){
    const h=harness(routes({child}));assert.equal((await h.player.resolve(page,{},meta)).length,0);
  }
  const h=harness(routes());assert.equal((await h.player.resolve(page,{},meta)).length,1);
});
test('truncated playlists and short preview playlists fail full-duration validation', async () => {
  for(const child of [VOD.replace('#EXT-X-ENDLIST',''),VOD.replace('#EXTINF:600,','#EXTINF:20,')]){
    const h=harness(routes({child}));assert.equal((await h.player.resolve(page,{},meta)).length,0);
  }
});
test('external variant playlists are rejected without forwarding the page issued URL to another host', async () => {
  const h=harness(routes({master:MASTER.replace('stream.php?v=fixture&p=720&token=issued-public-fixture','https://evil.test/api/stream.php?token=fixture')}));
  assert.equal((await h.player.resolve(page,{},meta)).length,0);assert.equal(h.calls.length,2);
});
test('cross-origin final responses are rejected at iframe, master and child stages', async () => {
  for(const changes of [{frameURL:'https://evil.test/'},{masterURL:'https://evil.test/'},{childURL:'https://evil.test/'}]){
    const h=harness(routes(changes));assert.equal((await h.player.resolve(page,{},meta)).length,0);
  }
});
test('each master variant is validated and a failing frame does not discard independent usable frames', async () => {
  const second=HOST+'/assets/js/s.php?s=fixture_other_22';
  const h=harness((url,opts,n)=>url===second?Promise.reject(new Error('HTTP403')):routes()(url,opts,n));
  const result=await h.player.resolve({url:page.url,html:page.html+'<div data-pv="fixture_other_22"></div>'},{},meta);
  assert.equal(result.length,1);assert.equal(result[0].url,STREAM);
  const tooMany=MASTER+Array.from({length:4},()=>MASTER.split('\n').slice(-3).join('\n')).join('');
  const bounded=harness(routes({master:tooMany}));assert.equal((await bounded.player.resolve(page,{},meta)).length,0);assert.equal(bounded.calls.length,2);
});
test('an otherwise usable master is rejected if any advertised variant is protected or unavailable', async () => {
  const second=HOST+'/api/stream.php?v=fixture&p=1080&token=issued-public-fixture';
  const master=MASTER+'#EXT-X-STREAM-INF:RESOLUTION=1920x1080,CODECS="avc1.4d4028,mp4a.40.2",AUDIO="dual"\n'+second+'\n';
  const h=harness((url,opts,n)=>url===second?{body:VOD.replace('METHOD=AES-128','METHOD=SAMPLE-AES'),finalUrl:url}:routes({master})(url,opts,n));
  assert.equal((await h.player.resolve(page,{},meta)).length,0);
  assert.ok(h.calls.some(c=>c.url===CHILD));assert.ok(h.calls.some(c=>c.url===second));
});
test('direct VOD HLS remains playable with Auto quality when its manifest declares no resolution', async () => {
  const h=harness(routes({master:VOD}));const result=await h.player.resolve(page,{},meta);
  assert.equal(result.length,1);assert.equal(result[0].quality,'Auto');assert.equal(h.calls.length,2);
});
test('missing or unsupported page inputs fail closed without network access', async () => {
  const h=harness(()=>{throw new Error('Must not fetch');});
  assert.equal((await h.player.resolve(null,{},meta)).length,0);
  assert.equal((await h.player.resolve({url:'http://site.test/',html:page.html},{},meta)).length,0);
  assert.equal((await h.player.resolve({url:page.url,html:'No player available'},{},meta)).length,0);
  assert.equal(h.calls.length,0);
});
